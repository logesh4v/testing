package Java_Test_Feb;

import java.util.Scanner;
 
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CourseManagementSystem cms = new CourseManagementSystem();
 
        System.out.print("Enter number of courses: ");
        int n = scanner.nextInt();
 
        for (int i = 0; i < n; i++) {
            System.out.print("Enter Course Number: ");
            int courseId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
 
            System.out.print("Enter Course Title: ");
            String courseName = scanner.nextLine();
 
            System.out.print("Enter Instructor Name: ");
            String instructor = scanner.nextLine();
 
            System.out.print("Enter Duration (weeks): ");
            int duration = scanner.nextInt();
 
            System.out.print("Enter Fee: ");
            double fee = scanner.nextDouble();
            scanner.nextLine(); 
 
            System.out.print("Enter Type (Technical/Non-Technical): ");
            String type = scanner.nextLine();
 
            try {
                Course course;
                if (type.equalsIgnoreCase("Technical")) {
                    course = new TechnicalCourse(courseId, courseName, instructor, duration, fee);
                } else if (type.equalsIgnoreCase("Non-Technical")) {
                    course = new NonTechnicalCourse(courseId, courseName, instructor, duration, fee);
                } else {
                    System.out.println("Invalid course type!");
                    continue;
                }
                cms.addCourse(course);
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        }
 
        // Sort and display courses by fee
        cms.sortCoursesByFee();
        System.out.println("Courses sorted by fee:");
        System.out.printf("%-10s %-20s %-15s %-20s %-10s %-10s %-15s%n", "ID", "Course Name", "Type", "Instructor", "Duration", "Fee", "Discounted Fee");
        for (Course course : cms.getCourses()) {
            double discount = course.calculateDiscount();
            double discountedFee = course.fee - discount;
            String type = (course instanceof TechnicalCourse) ? "Technical" : "Non-Technical";
            System.out.printf("%-10d %-20s %-15s %-20s %-10d %-10.2f %-15.2f%n",
                    course.courseId, course.courseName, type, course.instructor, course.durationWeeks, course.fee, discountedFee);
        }
 
        // Filter and display courses with duration greater then 4 weeks
        System.out.println("\nCourses with duration > 4 weeks:");
        System.out.printf("%-10s %-20s %-20s %-10s %-10s %-20s%n", "ID", "Course Name", "Instructor", "Duration", "Fee", "Discounted Fee");
        for (Course course : cms.filterCoursesByDuration(4)) {
            double discount = course.calculateDiscount();
            double discountedFee = course.fee - discount;
            System.out.printf("%-10d %-20s %-20s %-10d %-10.2f %-20.2f%n",
                    course.courseId, course.courseName, course.instructor, course.durationWeeks, course.fee, discountedFee);
        }
    }
}
 