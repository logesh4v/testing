package Java_Test_Feb;

import java.util.*;
import java.util.stream.Collectors;
 
public class CourseManagementSystem {
    private LinkedList<Course> courses = new LinkedList<>();
 
    public void addCourse(Course course) {
        courses.add(course);
    }
 
    public void sortCoursesByFee() {
        courses.sort(Comparator.comparingDouble(course -> course.fee));
    }
 
    public List<Course> filterCoursesByDuration(int weeks) {
        return courses.stream()
                .filter(course -> course.durationWeeks > weeks)
                .collect(Collectors.toList());
    }
 
    public LinkedList<Course> getCourses() {
        return courses;
    }
}