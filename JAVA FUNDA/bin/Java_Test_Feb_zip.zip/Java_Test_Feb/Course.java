package Java_Test_Feb;

public abstract class Course {
    protected int courseId;
    protected String courseName;
    protected String instructor;
    protected int durationWeeks;
    protected double fee;
 
    public Course(int courseId, String courseName, String instructor, int durationWeeks, double fee) {
        if (durationWeeks <= 0 || fee <= 0) {
            throw new IllegalArgumentException("Duration and fee must be greater than zero.");
        }
        this.courseId = courseId;
        this.courseName = courseName;
        this.instructor = instructor;
        this.durationWeeks = durationWeeks;
        this.fee = fee;
    }
 
    public abstract double calculateDiscount();
}
